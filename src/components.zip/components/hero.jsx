import React from "react";

const Hero = () => {
  return (
    <section className="relative w-full h-screen flex items-center justify-center text-center text-white">
      {/* Background Image */}
      <div className="absolute inset-0 bg-black">
        <img
          src="https://img.freepik.com/free-photo/brave-small-child-gets-dental-treatment-by-expirienced-doctor-dental-clinic_613910-21734.jpg?uid=R60856154&ga=GA1.1.1412458065.1733763983&semt=ais_hybrid" // Change this to your actual image path
          alt="Hero Background"
          className="w-full h-full object-cover opacity-50"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-2xl px-6">
        <p className="text-sm uppercase tracking-widest">
          Welcome To <span className="text-red-500 font-semibold">DesignHub</span>
        </p>

        <h1 className="text-5xl md:text-6xl font-bold leading-tight m-2">
          Creating the Future With
          <span className="bg-gradient-to-t from-red-600 to-white bg-clip-text text-transparent "> DesignHub</span>
        </h1>

      

        <p className="text-lg text-gray-300">
          Lorem ipsum dolor sit amet consectetur. Aliquam quisque cursus proin
          adipiscing quis diam. Eu fringilla elit commodo nec aliquet. Augue
          pharetra nibh co.
        </p>

        {/* Buttons */}
        <div className="mt-6 flex justify-center gap-4">
          <button className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-md font-semibold">
            Hire Us
          </button>
          <button className="bg-white text-black hover:bg-gray-200 px-6 py-3 rounded-md font-semibold">
            View Portfolio
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
