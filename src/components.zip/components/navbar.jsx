import React, { useState } from "react";
import { FiMenu, FiX } from "react-icons/fi";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  // Function to close menu when a link is clicked
  const closeMenu = () => setIsOpen(false);

  return (
    <nav className="bg-black text-white py-4 px-10 flex items-center justify-between relative">
      {/* Logo */}
      <div className="flex items-center gap-2">
        <img src="/images/logo.png" alt="Logo" className="h-8 w-8" />
        <span className="text-xl font-semibold">DesignHub</span>
      </div>

      {/* Desktop Navigation */}
      <ul className="hidden md:flex gap-8 text-sm font-medium">
        <li className="text-red-500 cursor-pointer">Home</li>
        <li className="hover:text-red-500 transition cursor-pointer">About Us</li>
        <li className="hover:text-red-500 transition cursor-pointer">Services</li>
        <li className="hover:text-red-500 transition cursor-pointer">Portfolio</li>
        <li className="hover:text-red-500 transition cursor-pointer">Testimonials</li>
        <li className="hover:text-red-500 transition cursor-pointer">Faqs</li>
      </ul>

      {/* Contact Us Button (Desktop) */}
      <button className="hidden md:block bg-red-500 hover:bg-red-600 text-white font-semibold px-5 py-2 rounded-md shadow-md">
        Contact Us
      </button>

      {/* Hamburger Button (Mobile) */}
      <button className="md:hidden text-white text-2xl" onClick={() => setIsOpen(!isOpen)}>
        {isOpen ? <FiX /> : <FiMenu />}
      </button>

      {/* Mobile Menu (Fixed Fullscreen) */}
      {isOpen && (
        <div className="fixed top-0 left-0 w-full h-full bg-black text-white flex flex-col items-center justify-center gap-6 z-50">
          <a href="#" className="text-red-500 text-lg" onClick={closeMenu}>Home</a>
          <a href="#" className="hover:text-red-500 text-lg" onClick={closeMenu}>About Us</a>
          <a href="#" className="hover:text-red-500 text-lg" onClick={closeMenu}>Services</a>
          <a href="#" className="hover:text-red-500 text-lg" onClick={closeMenu}>Portfolio</a>
          <a href="#" className="hover:text-red-500 text-lg" onClick={closeMenu}>Testimonials</a>
          <a href="#" className="hover:text-red-500 text-lg" onClick={closeMenu}>Faqs</a>
          <button
            className="bg-red-500 hover:bg-red-600 text-white font-semibold px-5 py-2 rounded-md shadow-md"
            onClick={closeMenu}
          >
            Contact Us
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
